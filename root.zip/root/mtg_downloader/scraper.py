"""Archivo principal para realizar scrappeo de URLs con manejo de rate limit y reintentos."""
import asyncio
import httpx
import time
from functools import partial
import aiometer


async def _scrape(session: httpx.AsyncClient, url: str, result: list, max_retries: int = 3):
    for attempt in range(max_retries):
        try:
            response = await session.get(url)
            # Manejar rate limit (HTTP 429)
            if response.status_code == 429:
                retry_after = int(response.headers.get('Retry-After', 5))
                if attempt < max_retries - 1:
                    print(f"\033[33m[Rate Limit] Esperando {retry_after}s antes de reintentar...\033[0m")
                    await asyncio.sleep(retry_after)
                    continue
                else:
                    raise Exception(f"Rate limit después de {max_retries} intentos")
            
            response.raise_for_status()
            json = response.json()
            result.append((url, json))
            print(f"Scrappeo completado de {url}")
            return
        except asyncio.CancelledError:
            raise
        except Exception as e:
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                print(f"\033[33m[Reintento] Error en {url}: {e}. Reintentando en {wait_time}s...\033[0m")
                await asyncio.sleep(wait_time)
            else:
                print(f"\033[31mError de scrappeo después de {max_retries} intentos en {url}:\033[0m {e}")


async def scrape_json(urls : list, result, max_per_sec : int):
    start = time.time()

    async with httpx.AsyncClient(timeout=30.0) as session:
        scrape = partial(_scrape, session, result=result)

        await aiometer.run_on_each(
            scrape,
            urls,
            max_per_second=max_per_sec,
        )

    print(f"finished {len(urls)} requests in {time.time() - start:.2f} seconds")